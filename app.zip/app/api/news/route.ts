import { NextRequest, NextResponse } from "next/server";
import { fetchNewsExternal } from "@/lib/api";

export async function GET(req: NextRequest) {
  try {
    const search = req.nextUrl.searchParams;
    const q = search.get("q") ?? "Google topic:'financial and economic news'";
    const next = search.get("next") ?? null;

    const data = await fetchNewsExternal({ q, next });

    return NextResponse.json(data);
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch news" }, { status: 500 });
  }
}

export const dynamic = "force-dynamic";
