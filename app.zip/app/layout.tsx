import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { React } from "next/dist/server/route-modules/app-page/vendored/rsc/entrypoints";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "Vortex Finance - Portal Berita Ekonomi Terkini",
  description: "Pantau berita sentimen negatif Google dan ekonomi global.",
  icons: { // Tambahkan bagian ini
    icon: '/logo.svg', // Mengacu ke public/logo.svg
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="id">
      <body className={inter.className}>
        <div className="min-h-screen flex flex-col">
          <Header />
          <main className="flex-1">{children}</main>
          <Footer />
        </div>
      </body>
    </html>
  );
}