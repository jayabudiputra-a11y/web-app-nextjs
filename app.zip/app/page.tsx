import { fetchNews } from "@/lib/api";
import FeaturedNews from "@/components/news/FeaturedNews";
import NewsList from "@/components/news/NewsList";
import { Sidebar } from "@/components/layout/Sidebar";
import { AlertCircle, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import Link from "next/link";

interface PageProps {
  searchParams: Record<string, string | undefined>;
}

export default async function Home({ searchParams }: PageProps) {
  const query =
    typeof searchParams.q === "string"
      ? searchParams.q
      : "Google topic:'financial and economic news'";

  const newsData = await fetchNews({ q: query });

  const hasData = newsData.posts.length > 0;
  const featuredPost = hasData ? newsData.posts[0] : null;
  const remaining = hasData ? newsData.posts.slice(1) : [];

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        <div className="lg:col-span-8">

          {!hasData && (
            <div className="text-center py-10 bg-red-50 border rounded-xl">
              <AlertCircle className="mx-auto h-10 w-10 text-red-500 mb-3" />
              <h3 className="text-xl font-bold">Tidak ada data</h3>
              <p className="text-red-700 mb-4">
                API mungkin kehabisan kuota atau terjadi kesalahan.
              </p>

              <Button asChild>
                <Link href={`/?q=${encodeURIComponent(query)}`}>
                  <RotateCcw className="w-4 h-4 mr-2" /> Coba lagi
                </Link>
              </Button>
            </div>
          )}

          {hasData && (
            <>
              {featuredPost && <FeaturedNews article={featuredPost} />}
              <NewsList initialData={{ ...newsData, posts: remaining }} />
            </>
          )}
        </div>

        <aside className="lg:col-span-4">
          <div className="sticky top-24">
            <Sidebar />
          </div>
        </aside>
      </div>
    </div>
  );
}
