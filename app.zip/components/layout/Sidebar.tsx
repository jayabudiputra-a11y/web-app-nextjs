// components/layout/Sidebar.tsx
import { SITE_CONFIG } from "@/config/site";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ExternalLink, Coffee, TrendingUp, Mail, Wallet } from "lucide-react";

export function Sidebar() {
  return (
    <div className="space-y-6">
      {/* Profil Developer Widget */}
      <Card className="bg-gradient-to-br from-blue-600 to-blue-800 text-white border-none shadow-lg overflow-hidden relative">
        {/* Dekorasi background */}
        <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full blur-2xl -mr-10 -mt-10"></div>
        
        <CardHeader className="pb-2 relative z-10">
          <h3 className="font-bold text-lg flex items-center gap-2">
            <Coffee className="w-5 h-5" /> Dukung Creator
          </h3>
          <p className="text-xs text-blue-100 opacity-90">
            Website ini dikembangkan oleh <b>{SITE_CONFIG.author.name}</b>
          </p>
        </CardHeader>
        
        <CardContent className="space-y-3 relative z-10">
          {/* Tombol DANA Otomatis */}
          <Button 
            asChild 
            className="w-full bg-white text-blue-700 hover:bg-blue-50 font-bold shadow-md border-none justify-start gap-2 h-12"
          >
            <a href={SITE_CONFIG.links.danaApp} target="_blank" rel="noopener noreferrer">
              <Wallet className="w-5 h-5 text-blue-600" />
              <span>Donate via DANA</span>
            </a>
          </Button>

          {/* Tombol Email Outlook (FIXED: Menggunakan Link Web) */}
          <Button 
            asChild 
            variant="outline" 
            className="w-full justify-start gap-2 bg-blue-700/50 border-blue-400/30 text-white hover:bg-blue-600/50"
          >
            <a href={SITE_CONFIG.links.emailWeb} target="_blank" rel="noopener noreferrer">
              <Mail className="w-4 h-4" />
              <span>Email (Outlook Web)</span>
            </a>
          </Button>

          {/* Tombol Linktree */}
          <Button 
            asChild 
            variant="ghost" 
            className="w-full justify-start gap-2 text-blue-100 hover:bg-blue-700/30 hover:text-white"
          >
            <a href={SITE_CONFIG.links.linktree} target="_blank">
              <ExternalLink className="w-4 h-4" />
              <span>Linktree & Kontak</span>
            </a>
          </Button>
        </CardContent>
      </Card>

      {/* Market Summary Widget */}
      <Card>
        <CardHeader className="border-b border-gray-100 bg-gray-50/50 pb-3">
          <h3 className="font-semibold text-gray-900 flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-green-600" /> Market Movers
          </h3>
        </CardHeader>
        <CardContent className="pt-4">
          <ul className="space-y-4">
            <li className="flex justify-between items-center border-b border-gray-100 pb-2 last:border-0">
              <div>
                <span className="font-medium text-sm block">Google (GOOGL)</span>
                <span className="text-xs text-gray-500">Tech Sector</span>
              </div>
              <span className="text-red-600 text-sm font-bold bg-red-50 px-2 py-1 rounded">-1.2%</span>
            </li>
            <li className="flex justify-between items-center border-b border-gray-100 pb-2 last:border-0">
              <div>
                <span className="font-medium text-sm block">NVIDIA (NVDA)</span>
                <span className="text-xs text-gray-500">AI & Chips</span>
              </div>
              <span className="text-green-600 text-sm font-bold bg-green-50 px-2 py-1 rounded">+2.4%</span>
            </li>
            <li className="flex justify-between items-center">
              <div>
                <span className="font-medium text-sm block">Bitcoin (BTC)</span>
                <span className="text-xs text-gray-500">Crypto</span>
              </div>
              <span className="text-green-600 text-sm font-bold bg-green-50 px-2 py-1 rounded">+0.8%</span>
            </li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}