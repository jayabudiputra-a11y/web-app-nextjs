import Link from "next/link"
import { Newspaper, Search, Menu } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

export function Header() {
  return (
    <header className="sticky top-0 z-50 w-full border-b border-gray-200 bg-white/90 backdrop-blur-md supports-[backdrop-filter]:bg-white/60">
      <div className="container mx-auto flex h-16 items-center justify-between px-4">
        
        {/* 1. Logo Section - Fixed Width */}
        <div className="flex items-center gap-2 shrink-0 mr-8">
          <Link href="/" className="flex items-center gap-2">
            <div className="bg-blue-600 p-1.5 rounded-lg shadow-sm">
              <Newspaper className="h-5 w-5 text-white" />
            </div>
            <span className="text-xl font-bold text-gray-900 hidden md:block">
              Vortex<span className="text-blue-600">Finance</span>
            </span>
          </Link>
        </div>
        
        {/* 2. Navigation Menu - Center & No Scroll */}
        {/* whitespace-nowrap: Mencegah teks turun ke bawah */}
        {/* hidden md:flex: Hanya muncul di layar sedang ke atas */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-gray-600 whitespace-nowrap">
          <Link href="/" className="hover:text-blue-600 transition-colors py-2">
            Beranda
          </Link>
          <Link href="/?q=crypto" className="hover:text-blue-600 transition-colors py-2">
            Crypto
          </Link>
          <Link href="/?q=stock" className="hover:text-blue-600 transition-colors py-2">
            Saham
          </Link>
          <Link href="/?q=economy" className="hover:text-blue-600 transition-colors py-2">
            Ekonomi Global
          </Link>
        </nav>

        {/* 3. Search & Action - Right Side */}
        <div className="flex items-center gap-2 ml-auto">
          <div className="relative hidden lg:block w-64">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-400" />
            <Input 
              type="search" 
              placeholder="Cari berita..." 
              className="pl-9 h-9 bg-gray-50 border-gray-200 focus:bg-white transition-all" 
            />
          </div>
          <Button size="sm" className="bg-blue-600 hover:bg-blue-700 text-white shadow-sm h-9">
            Subscribe
          </Button>
          {/* Mobile Menu Button */}
          <Button size="icon" variant="ghost" className="md:hidden">
            <Menu className="h-5 w-5" />
          </Button>
        </div>

      </div>
    </header>
  )
}