// components/layout/Footer.tsx
import { SITE_CONFIG } from "@/config/site";
import { Mail, Phone, Wallet, ArrowUpRight } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-gray-900 text-gray-300 py-12 border-t border-gray-800 mt-auto">
      <div className="container mx-auto px-4 grid grid-cols-1 md:grid-cols-3 gap-8">
        
        {/* Kolom 1: Brand */}
        <div>
          <h3 className="text-white text-xl font-bold mb-4 flex items-center gap-2">
            Vortex Finance
          </h3>
          <p className="text-sm text-gray-400 leading-relaxed mb-4">
            Sumber berita keuangan terpercaya dengan analisis mendalam. 
            Menyajikan data real-time untuk keputusan investasi cerdas Anda.
          </p>
        </div>
        
        {/* Kolom 2: Kontak (Klik langsung connect) */}
        <div>
          <h3 className="text-white text-lg font-bold mb-4">Hubungi Kami</h3>
          <ul className="space-y-4 text-sm">
            <li>
              <a 
                href={SITE_CONFIG.links.email} 
                className="group flex items-center gap-3 hover:text-white transition-colors"
              >
                <div className="bg-gray-800 p-2 rounded-lg group-hover:bg-blue-600 transition-colors">
                  <Mail className="w-4 h-4" />
                </div>
                <span>{SITE_CONFIG.author.email}</span>
              </a>
            </li>
            <li>
              <a 
                href={SITE_CONFIG.links.whatsapp}
                target="_blank"
                rel="noopener noreferrer" 
                className="group flex items-center gap-3 hover:text-white transition-colors"
              >
                <div className="bg-gray-800 p-2 rounded-lg group-hover:bg-green-600 transition-colors">
                  <Phone className="w-4 h-4" />
                </div>
                <span>{SITE_CONFIG.author.phone} (WhatsApp)</span>
              </a>
            </li>
          </ul>
        </div>

        {/* Kolom 3: Donasi (DANA) */}
        <div>
          <h3 className="text-white text-lg font-bold mb-4">Dukungan</h3>
          <div className="bg-gray-800/50 p-5 rounded-xl border border-gray-700 hover:border-blue-500/50 transition-colors">
            <p className="text-xs text-gray-400 mb-3 uppercase tracking-wider font-semibold">
              Dukung via DANA
            </p>
            
            {/* Link ke DANA */}
            <a 
              href={SITE_CONFIG.links.danaApp}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-between group"
            >
              <div className="flex items-center gap-3 text-white font-mono font-medium text-lg">
                <Wallet className="w-6 h-6 text-blue-400" />
                {SITE_CONFIG.author.dana}
              </div>
              <ArrowUpRight className="w-4 h-4 text-gray-500 group-hover:text-blue-400 transition-colors" />
            </a>
            
            <p className="text-[10px] text-gray-500 mt-2">
              Klik nomor di atas untuk membuka aplikasi DANA
            </p>
          </div>
        </div>
      </div>
      
      {/* Copyright */}
      <div className="container mx-auto px-4 mt-8 pt-8 border-t border-gray-800 text-center text-xs text-gray-500">
        <p>&copy; {new Date().getFullYear()} Vortex Finance. Powered by Webz.io.</p>
        <p className="mt-1">Developed with ❤️ by {SITE_CONFIG.author.name}</p>
      </div>
    </footer>
  )
}