import Image from "next/image";
import { NewsPost } from "@/types/news";
import { formatDate } from "@/lib/utils";

interface FeaturedNewsProps {
  article: NewsPost;
}

export default function FeaturedNews({ article }: FeaturedNewsProps) {
  if (!article) return null;

  const imageSrc = article.main_image || "/placeholder.jpg";
  const titleText = article.title || "Untitled";
  const siteText = article.thread?.site || "Unknown Source";
  const publishedDate = article.published || "";
  const descriptionText = article.description || "";
  const url = article.url || "#";

  return (
    <div className="mb-10 rounded-xl overflow-hidden border bg-white shadow-sm hover:shadow-md transition">
      {article.main_image && (
        <div className="relative h-64 w-full">
          <Image
            src={imageSrc}
            alt={titleText}
            fill
            className="object-cover"
            sizes="100vw"
          />
        </div>
      )}

      <div className="p-6">
        <div className="flex justify-between items-center mb-2">
          <span className="text-sm text-blue-600 font-semibold">
            {siteText}
          </span>

          <span className="text-xs text-gray-500">
            {formatDate(publishedDate)}
          </span>
        </div>

        <h2 className="text-2xl font-bold mb-3">{titleText}</h2>

        {descriptionText && (
          <p className="text-gray-600 mb-4">
            {descriptionText.slice(0, 200)}...
          </p>
        )}

        <a
          href={url}
          target="_blank"
          rel="noopener noreferrer"
          className="text-blue-600 hover:underline font-medium"
        >
          Baca selengkapnya →
        </a>
      </div>
    </div>
  );
}
