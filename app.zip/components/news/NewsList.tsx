"use client";

import { useEffect, useState } from "react";
import NewsCard from "./NewsCard";
import FeaturedNews from "./FeaturedNews";
import Loading from "../ui/Loading";
import ErrorMessage from "../ui/ErrorMessage";
import Pagination from "../ui/Pagination";
import EmptyState from "../ui/EmptyState";
import { useCursorPagination } from "@/lib/useCursorPagination";
import { XCircle } from "lucide-react";
import { NewsPost } from "@/types/news";

export default function NewsList() {
  const [newsData, setNewsData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const { page, setPage, saveNextCursor, getCursorForPage, hasPrevious, hasNext } =
    useCursorPagination();

  const fetchNews = async () => {
    try {
      setLoading(true);

      const ts = getCursorForPage(page);
      const res = await fetch(`/api/news?size=20${ts ? `&ts=${ts}` : ""}`);
      const data = await res.json();

      if (!res.ok) throw new Error(data.error);

      saveNextCursor(page + 1, data.next);

      setNewsData(data);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchNews();
  }, [page]);

  if (loading) return <Loading />;
  if (error) return <ErrorMessage message={error} />;

  if (!newsData?.posts?.length)
    return (
      <EmptyState
        title="Tidak Ada Berita Ditemukan"
        description="Coba gunakan query lain."
        icon={<XCircle className="w-16 h-16 text-red-400" />}
      />
    );

  const featuredArticle = newsData.posts[0];
  const listArticles = newsData.posts.slice(1);

  return (
    <div>
      <FeaturedNews article={featuredArticle} />

      <div className="my-6">
        <h3 className="text-xl font-semibold">Artikel Terbaru Lainnya</h3>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {listArticles.map((item: NewsPost) => (
          <NewsCard key={item._id} news={item} />
        ))}
      </div>

      <div className="mt-10 flex justify-center">
        <Pagination
          currentPage={page}
          totalPages={page + (newsData.next ? 1 : 0)}
          onPageChange={setPage}
        />
      </div>
    </div>
  );
}
