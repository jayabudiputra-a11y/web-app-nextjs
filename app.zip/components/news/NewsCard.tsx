import * as React from "react";
import { NewsPost } from "@/types/news";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { truncateText, formatDate } from "@/lib/utils";
import Image from "next/image";

interface NewsCardProps {
  news: NewsPost;
}

export default function NewsCard({ news }: NewsCardProps) {
  if (!news) return null;

  const imageSrc = news.main_image || "/placeholder.jpg";
  const titleText = news.title || "Untitled";
  const siteText = news.thread?.site || "Unknown Source";
  const publishedDate = news.published || "";
  const descriptionText = news.description || "";
  const url = news.url || "#";

  return (
    <Card className="overflow-hidden hover:shadow-lg transition-shadow">
      {news.main_image && (
        <div className="relative h-48 w-full">
          <Image
            src={imageSrc}
            alt={titleText}
            fill
            className="object-cover"
            sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
          />
        </div>
      )}

      <CardHeader>
        <div className="flex items-start justify-between gap-2">
          <Badge variant="outline">{siteText}</Badge>

          <span className="text-xs text-muted-foreground">
            {formatDate(publishedDate)}
          </span>
        </div>

        <CardTitle className="text-lg line-clamp-2">{titleText}</CardTitle>
      </CardHeader>

      <CardContent>
        <p className="text-sm text-muted-foreground line-clamp-3">
          {truncateText(descriptionText, 150)}
        </p>

        <a
          href={url}
          target="_blank"
          rel="noopener noreferrer"
          className="text-sm text-primary hover:underline mt-2 inline-block"
        >
          Read more →
        </a>
      </CardContent>
    </Card>
  );
}
