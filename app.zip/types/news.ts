export interface NewsThread {
  site?: string;
  section_title?: string;
  main_image?: string;
}

export interface NewsPost {
  uuid: string;
  url: string;
  title: string;
  text?: string;
  description?: string;
  published: string;
  author?: string;

  // Webz.io field
  main_image?: string;

  thread?: NewsThread;
}

export interface NewsResponse {
  posts: NewsPost[];
  totalResults: number;
  moreResultsAvailable: number;
  next: string | null;
}
