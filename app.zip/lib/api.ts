import { NewsResponse, NewsPost } from "@/types/news";

const API_KEY = process.env.WEBZ_API_KEY!;
const BASE_URL = "https://api.webz.io/news-api/v1/search";

export interface FetchNewsParams {
  q?: string;
  size?: number;
  next?: string | null;
}

// Response kosong jika error
function emptyResponse(): NewsResponse {
  return {
    posts: [],
    totalResults: 0,
    moreResultsAvailable: 0,
    next: null,
  };
}

export async function fetchNews(params: FetchNewsParams): Promise<NewsResponse> {
  const { q = "Google topic:'financial and economic news'", size = 10, next } = params;

  try {
    const url = new URL(BASE_URL);
    url.searchParams.set("token", API_KEY);
    url.searchParams.set("q", q);
    url.searchParams.set("size", String(size));
    if (next) url.searchParams.set("next", next);

    const res = await fetch(url.toString(), { next: { revalidate: 60 } });
    if (!res.ok) return emptyResponse();

    const data = await res.json();
    return {
      posts: Array.isArray(data.posts) ? data.posts : [],
      totalResults: data.totalResults ?? 0,
      moreResultsAvailable: data.moreResultsAvailable ?? 0,
      next: data.next ?? null,
    };

  } catch (e) {
    console.error(e);
    return emptyResponse();
  }
}

export async function fetchNewsExternal(params: FetchNewsParams): Promise<NewsResponse> {
  return fetchNews(params);
}
